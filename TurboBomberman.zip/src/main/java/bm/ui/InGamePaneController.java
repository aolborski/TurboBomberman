package bm.ui;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.layout.Pane;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static bm.ui.BmState.MENU;

@Component
public class InGamePaneController implements NodeController {

    @Autowired
    private BmContext bmContext;

    @FXML
    private Pane inGamePane;

    @FXML
    public void initialize() {

    }

    @FXML
    public void onBackToMenu() {
        bmContext.stateProperty().setValue(MENU);
    }

    @NotNull
    @Override
    public Node getNode() {
        return inGamePane;
    }
}