package bm.model.actors;

public enum MovementDirection {
  UP, DOWN, RIGHT, LEFT, NONE
}
