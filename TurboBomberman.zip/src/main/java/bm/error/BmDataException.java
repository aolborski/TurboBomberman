package bm.error;

public class BmDataException extends RuntimeException {

  public BmDataException(String message) {

    super(message);
  }
}
