package bm.ui;

public enum BmState {

  MENU, IN_GAME
}
