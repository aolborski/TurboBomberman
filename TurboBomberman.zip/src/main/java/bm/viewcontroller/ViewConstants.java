package bm.viewcontroller;

public class ViewConstants {

  public static final Double FIELD_WORLD_SIZE = 24.0;

  public static final Double BM_SPEED = 2.0;
}
