package bm.ui;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static bm.ui.BmState.IN_GAME;

@Component
public class MenuPaneController implements NodeController {

  @Autowired
  private BmContext bmContext;

  @FXML
  private BorderPane menuPane;

  private static final Logger LOG = LoggerFactory.getLogger(MenuPaneController.class);

  @NotNull
  @Override
  public Node getNode() {

    return menuPane;
  }

  @FXML
  public void onNewGame() {

    bmContext.stateProperty().setValue(IN_GAME);
  }

  @FXML
  public void onExit() {

    System.exit(0);
  }
}
