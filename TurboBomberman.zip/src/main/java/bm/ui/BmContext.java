package bm.ui;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Component;

@Component
public class BmContext {

  @NotNull
  private final ObjectProperty<BmState> state;


  public BmContext() {

    state = new SimpleObjectProperty<>(BmState.MENU);
  }

  public ObjectProperty<BmState> stateProperty() {

    return state;
  }
}
