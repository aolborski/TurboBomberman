package bm.model.actors;

public interface BombPlanter {

  void plant();
}
