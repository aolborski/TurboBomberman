package bm.ui;

import javafx.scene.Node;
import org.jetbrains.annotations.NotNull;

public interface NodeController {

  @NotNull
  Node getNode();
}
