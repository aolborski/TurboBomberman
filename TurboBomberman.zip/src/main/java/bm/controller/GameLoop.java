package bm.controller;


import bm.Constants;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.Event;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.BlockingQueue;

import static bm.Constants.DEBUG_FAST_FPS;
import static bm.Constants.RELEASE_FAST_FPS;
import static javafx.animation.Animation.INDEFINITE;
import static org.slf4j.LoggerFactory.getLogger;

/**
 *
 */
@Component
public class GameLoop {
    private final static Logger LOGGER = getLogger(GameLoop.class);

    /**
     * The game loop using JavaFX's <code>Timeline</code> API.
     */
    private static Timeline gameLoop;

    @Autowired
    GameWorldController gameWorldController;

    /**
     * Constructor
     */
    public GameLoop() {
        buildAndSetGameLoop();
    }

    /**
     * Builds and sets the game loop ready to be started
     */
    private final void buildAndSetGameLoop() {
        final Duration oneFrameAmount = Duration.millis(RELEASE_FAST_FPS);
        final KeyFrame oneFrame = new KeyFrame(oneFrameAmount, event -> {
//            LOGGER.debug("TICK");

            // update actors
            gameWorldController.update();

            // check for collision
            gameWorldController.handleCollision();

            // another logic systems update

            // removed dead entity
        });

        // sets the game world's game loop (Timeline)
        gameLoop = new Timeline(oneFrame);
        gameLoop.setCycleCount(INDEFINITE);
    }

    /**
     * Kick off (plays) the TimeLine.
     */
    public void beginGameLoop() {
        gameLoop.play();
    }

    /**
     * Stop threads and stop media from playing
     */
    public void stopGameLoop() {
        gameLoop.stop();
        // stopGameLoop sound manager
    }
}
