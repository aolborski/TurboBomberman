package bm.model.level.obstacle;

import bm.model.HasApexPosition;
import org.jetbrains.annotations.NotNull;

public interface Obstacle extends HasApexPosition {

}
